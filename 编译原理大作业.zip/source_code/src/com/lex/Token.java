package com.lex;

public class Token {
    public static final int ID = 1;
    public static final int KEYWORD = 2;
    public static final int DELIMITER = 5;
    public static final int INT = 6;
    public static final int FLOAT = 12;
    public static final int CHAR = 13;
    public static final int STR = 14;
    public static final int EOF = 15;
    public static final int OPERATOR = 15;

    public String value;
    public int type;
    public int line;
    public int rowNumber;
    /**
     *
     * @param v 标识符
     * @param t 标识符类型
     */
    public Token(String v,int t,int rowNumber){
        this.value=v;
        this.type=t;
        this.rowNumber = rowNumber;
    }

}
