package com.lex;

import java.util.ArrayList;


public class Lexer {
    public final static String[] KW = {"include","struct","NULL","int","double","long","float","short","boolean","while","if","for","do","return","break","case","continue","define","goto","void","char"};
    private int rowNumber;
    private int pointer;
    private char [] ctext;
    private long tlen;
    private int indexOfToken;

    private ArrayList<Token> tks;
    private ArrayList<TokenError> errors;

    public Lexer(String text){
        this.tlen = text.length();
        this.ctext = text.toCharArray();
        this.tks = new ArrayList<>();
        this.errors = new ArrayList<>();
        rowNumber = 1;

    }
    public Lexer start(){
        char c;
        if (tlen<=0){
            System.out.println("无效的输入");
            System.exit(0);
        }
        while (pointer<tlen){
            c = ctext[pointer];
            if (c==' '||c=='\t') pointer++;
            else if (c=='\n'){
                rowNumber++;
                pointer++;
            }else if (c=='\r' &&ctext[pointer+1]=='\n'){
                rowNumber++;
                pointer+=2;
            }
            else{
                analyzer(c);
            }
        }
        return this;

    }
    private void add(Token tk){
        tks.add(tk);
        indexOfToken++;
    }
    //分析
    private void analyzer(char c){
        if (Character.isDigit(c)){
            // 如果第一个字母是数字，
            String tk = next();
            if (isNumeric(tk)){
                add(new Token(tk,Token.INT,rowNumber));
            }else{
                errors.add(new TokenError(rowNumber,tk + "是非法的数字或者标识符"));
            }
        }else if (Character.isJavaIdentifierPart(c)){
            /*
             *  第一个是字母 则可能是 标识符，保留字
             * */
            String tk = next();

            if (isIdentify(tk)){
                if (isKeyword(tk)){
                    add(new Token(tk,Token.KEYWORD,rowNumber));
                }else{ // 标识符
                    add(new Token(tk,Token.ID,rowNumber));
                }
            }else{
                errors.add(new TokenError(rowNumber, tk + " 是非法的标识符或关键字"));
            }

        }else if(c=='"'){
            String tk = next();
            if (isStringConst(tk)){
                add(new Token(tk.replaceAll("\"",""),Token.STR,rowNumber));
            }else{
                errors.add(new TokenError(rowNumber,"缺少\""));
            }
        }else if(c=='\''){
            String tk = next();
            if(tk.charAt(0)=='\'' &&tk.charAt(tk.length()-1)=='\''){
                add(new Token(tk,Token.CHAR,rowNumber));
            }else{
                errors.add(new TokenError(rowNumber,"缺少\'"));
            }
        }
        else{

           switch (c){
               case '[':
               case ']':
               case ',':
               case ';':
               case '(':
               case ')':
               case '{':
               case '}':
                   add(new Token(c+"",Token.DELIMITER,rowNumber));
                   break;
               case '+':

                   /*
                   *  可能是 += ++ +
                   * */
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='+'){ // ++
                           add(new Token("++",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else if (ctext[pointer+1]=='='){//+=
                           add(new Token("+=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("+",Token.OPERATOR,rowNumber));
                       }
                   }
                   break;
               case '-':
                   /*
                   *  可能是 -= ,--,-
                   * */
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='-'){ // ++
                           add(new Token("--",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else if (ctext[pointer+1]=='='){//+=
                           add(new Token("-=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("-",Token.OPERATOR,rowNumber));
                       }
                   }else{
                       errors.add(new TokenError(rowNumber,"在“-”附近发生错误!"));
                   }
                   break;
               case '!':
                   /*
                   *  可能是 ! ,!=
                   * */
                   if (pointer<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("!=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("!",Token.OPERATOR,rowNumber));
                       }
                   }else {
                       errors.add(new TokenError(rowNumber,"在“!”附近发生错误!"));
                   }
                   break;
               case '=':
                   /*
                   * 可能是 =,==
                   * */
                   if (pointer<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("==",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else{
                           add(new Token("=",Token.OPERATOR,rowNumber));
                       }
                   }else {
                       errors.add(new TokenError(rowNumber,"在“=”附近发生错误!"));
                   }
                   break;
               case '<':
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("<=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("<",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“<”附近发生错误!"));
                   break;
               case '>':
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token(">=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token(">",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“>”附近发生错误!"));
                   break;
               case '*':
                   /*
                   *  可能 *,*= ,
                   *
                   * */
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("*=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("*",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“*”附近发生错误!"));
                   break;
               case '/':
                   /*
                   *  可能是 /,//,/=，
                   *  多行注释 以/*开头以 star star/结尾
                   * */
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("/=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else if (ctext[pointer+1]=='/'){
                           while (pointer<tlen&&(ctext[pointer]!='\n'&&ctext[pointer]!='\r')) pointer++;
                           rowNumber++;
                       } else if (ctext[pointer+1]=='*'){ // 多行注释
                           while (pointer<tlen){
                               if (ctext[pointer]=='\n'||ctext[pointer]=='\r') rowNumber++;
                              if (ctext[pointer]=='/'&&ctext[pointer-1]=='*'&&ctext[pointer-2]=='*'){
                                  break;
                              }
                              pointer++;
                           }
                       } else{
                           add(new Token("/",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“/”附近发生错误!"));
                   break;
               case '%':
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='='){
                           add(new Token("%=",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("%",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“%”附近发生错误!"));
                   break;

               case '#':
                   //预处理忽略
                   break;
               case '.':
                   //成员运算 忽略
                   break;
               case '&':
                   // 逻辑与 算数与
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='&'){
                           add(new Token("&&",Token.OPERATOR,rowNumber));
                           pointer++;
                       }else {
                           add(new Token("&",Token.OPERATOR,rowNumber));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“%”附近发生错误!"));

                   break;
               case '|':
                   //逻辑或 算术或
                   if (pointer+1<tlen){
                       if (ctext[pointer+1]=='|'){
                           add(new Token("||",Token.OPERATOR,Token.OPERATOR));
                           pointer++;
                       }else {
                           add(new Token("|",Token.OPERATOR,Token.OPERATOR));
                       }
                   }else errors.add(new TokenError(rowNumber,"在“%”附近发生错误!"));

                   break;
               default:errors.add(new TokenError(rowNumber,c+"是非法的语句成分"));break;
           }
           pointer++;
        }
    }
    public String next(){
        StringBuilder b= new StringBuilder();
        while (pointer<tlen){
            if (Character.isJavaIdentifierPart(ctext[pointer])||Character.isDigit(ctext[pointer])){
                b.append(ctext[pointer]);
                pointer++;
            }else if (ctext[pointer]=='"'){
                b.append(ctext[pointer]);
                pointer++;
                while (pointer<tlen&&ctext[pointer]!='"'){
                    b.append(ctext[pointer]);
                    pointer++;
                }
                if (pointer >= tlen) {
                    System.out.println("未匹配到\"");
                    System.exit(0);
                }
                b.append(ctext[pointer++]);
                return b.toString();
            }else if(ctext[pointer]=='\''){
                b.append(ctext[pointer]);
                pointer++;
                while (pointer<tlen&&ctext[pointer]!='\''){
                    b.append(ctext[pointer]);
                    pointer++;
                }
                b.append(ctext[pointer++]);
                return b.toString();
            }
            else {
                return b.toString();
            }
        }
        return b.toString();
    }
    public boolean isStringConst(String t){
        return t.charAt(0) == '"'&&t.charAt(t.length()-1)=='"';
    }
    public boolean isNumeric(String word) {
        return isDecimal(word) || isBinaryNumber(word) || isHexNumber(word) || isOctNumber(word);
    }
    private boolean isHexNumber(String word){
        if (word.length() < 3) return false;
        char ct[] = word.toCharArray();
        if (ct[0]=='0' && (ct[1]) == 'x' || ct[1] == 'X') {
            for (int i = 2; i < ct.length; i++) {
                if (!(Character.isDigit(ct[i]) || (ct[i] >= 'a' && ct[i] <= 'f') || (ct[i] >= 'A' && ct[i] <= 'F')))
                    return false;
            }
            return true;
        }
        return false;
    }

    private boolean isBinaryNumber(String word){
        if (word.length() < 3) return false;
        char ct[] = word.toCharArray();
        if (ct[0] == '0' && (ct[1] == 'b' || ct[1] == 'B')) {
            for (int i = 2; i < ct.length; i++) {
                if (!(ct[i] == '1' || ct[i] == '0')) return false;
            }
            return true;
        }
        return false;
    }
    private boolean isOctNumber(String word){
        if (word.length()<2) return false;
        char ct[] = word.toCharArray();
        if (ct[0] == '0') {
            for (int i = 1; i < ct.length; i++) {
                if (ct[i] < '0' || ct[i] >'7') return false;
            }
            return true;
        }
        return false;
    }
    private boolean isDecimal(String word){
        if (word.length()<1) return false;
        char ct[] = word.toCharArray();
        for(int i=0;i<ct.length;i++){
            if (!Character.isDigit(ct[i])) return false;
        }
        return true;
    }

    public boolean isIdentify(String tk){
        char [] ctk = tk.toCharArray();
        if (!Character.isLetter(ctk[0])&&ctk[0]!='_') return false;
        else if (tk.length()==1) return true;
        for(int i=1;i<ctk.length;i++){
           if (!(Character.isLetter(ctk[i])||ctk[i]=='_'||Character.isDigit(ctk[i]))) return false;
        }
        return true;
    }
    public boolean isKeyword(String tk){
        for(String k:KW){
            if(k.equals(tk)) return true;
        }
        return false;
    }

    public ArrayList<Token> getTks() {
        return tks;
    }
    public ArrayList<TokenError> getErrors(){
        return errors;
    }
    public boolean isHasError(){
        return errors.size()>0;
    }
    public int tkPoint;

    public Token scanner(){
        Token ret = null;
        if (tkPoint<tks.size()){
            ret = tks.get(tkPoint);
            tkPoint++;
        }
        return ret;
    }



}

