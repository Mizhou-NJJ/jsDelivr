package com.grammar;

import java.io.*;
import java.util.*;

public class GrammarResolver {
    //用于保存非终结符
    private HashSet<String> nts = new HashSet<>();
    private Hashtable<String,HashSet<String>> first;
    private List<Production> productions;
    private Hashtable<String,HashSet<String>> follow;
    HashSet<String> setOfNullable = new HashSet<>();
    public List<String> readGrammar(String filePath){
        List<String> rules = new ArrayList<>();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line= reader.readLine())!=null){
                if (!((line.length()<=2) ||(line.charAt(0) == '/') && (line.charAt(1)=='/'))){
                    rules.add(line);
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                reader.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return rules;
    }
    public List<Production> resolve(String filePath){
        productions = resolveGrammar(readGrammar(filePath));
        setOfNullable = nullable(productions);
        first  = first(productions);
        follow = follow(productions);
        //select
        for(Production item:productions){
            //如果右部第一个是终结符,直接添加至自己的select集合
            if (item.right.type== GrammarSymbol.T){
                item.select.add(item.right);
            }
            //如果右部第一个不是终结符,将first集合添加至select集合
            else if (item.right.type== GrammarSymbol.NT){
                item.select.addAll(toSymbol(first.get(item.right.value)));
            }
            //如果右部第一个是空串,将follow集合添加至select集合
            else if (item.right.type== GrammarSymbol.EPS){
                item.select.addAll(toSymbol(follow.get(item.left.value)));
            }
        }
        return productions;

    }
    private HashSet<GrammarSymbol> toSymbol(HashSet<String> set){
        HashSet<GrammarSymbol> setSym = new HashSet<>();
        for(String s:set){
            if (!s.equals("ε")){
                GrammarSymbol symbol = new GrammarSymbol();
                symbol.type = GrammarSymbol.T;
                symbol.value = s;
                setSym.add(symbol);
            }
        }
        return setSym;
    }
    private List<Production> resolveGrammar(List<String> rules){
        List<Production> productions = new ArrayList<>();
        nts = getNts(rules);
        for (String rule : rules){
            String [] byDeduce = rule.split("->");
            String left = byDeduce[0].replaceAll(" ","");
            String [] byOr = byDeduce[1].split("\\|");
            for (String or : byOr){
                Production p = new Production();
                p.left = new GrammarSymbol(left,GrammarSymbol.NT,null);
                String [] byBlank = or.split(" ");
                GrammarSymbol curr = null;
                for (String part: byBlank){
                    if (!(part.equals(""))){
                        int symType;
                        if (part.equals(GrammarSymbol.EPSILON)) symType = GrammarSymbol.EPS;
                        else if (isNt(part)) symType = GrammarSymbol.NT;
                        else symType = GrammarSymbol.T;
                        if (p.right == null){
                            p.right = new GrammarSymbol(part,symType);
                            curr = p.right;
                        }else {
                            curr.next = new GrammarSymbol(part,symType);
                            curr = curr.next;
                        }
                    }
                }
                productions.add(p);
            }

        }
        return productions;
    }
    private boolean isNt(String part){
        return nts.contains(part);
    }
    private HashSet<String> getNts(List<String> rules){
        HashSet<String> ___ = new HashSet<>();
        for (String rule:rules){
            String [] _ = rule.split("->");
            ___.add(_[0].trim());
        }
        return ___;
    }

    /**
     *
     * @param productions 产生式列表
     * @return 可推出空串的非终极符集合，方便first集合和follow集合的计算
     */
    private HashSet<String> nullable(List<Production> productions){
        HashSet<String> setOfNullable = new HashSet<>();
        boolean isChanged = true;
        while (isChanged){
            isChanged = false;
            for (Production item:productions){
                GrammarSymbol gm = item.right;
                if (gm.type == GrammarSymbol.EPS){
                    isChanged = setOfNullable.add(item.left.value);
                }else if (gm.type==GrammarSymbol.NT && setOfNullable.contains(gm.value)){
                    boolean tag = true;
                    while (gm!=null){
                        if (gm.type!=GrammarSymbol.NT || !setOfNullable.contains(gm.value)){
                            tag = false;
                            break;
                        }
                        gm = gm.next;
                    }
                    if (tag){
                        isChanged = setOfNullable.add(item.left.value);
                    }
                }
            }
        }
        return setOfNullable;
    }

    /**
     * 计算ps的first集合
     * @param ps
     * @return
     */
    private Hashtable<String,HashSet<String>> first(List<Production> ps){
        Hashtable<String,HashSet<String>> table = new Hashtable<>();
        for (Production item: ps){
            if (!table.containsKey(item.left.value)){
                table.put(item.left.value,new HashSet<>());
            }
        }
        boolean isChanged = true;
        while (isChanged){
            isChanged = false;
            for (Production item:ps){
                HashSet<String> row = table.get(item.left.value);
                GrammarSymbol p = item.right;
                if (p.type == GrammarSymbol.EPS){
                    if (row.add(p.value)) isChanged = true;
                }else if (p.type == GrammarSymbol.T){
                    if (row.add(p.value)) isChanged = true;
                }else {
                    // 非终结符情况
                    while (p!=null && p.type == GrammarSymbol.NT){
                        if (row.addAll(table.get(p.value))) isChanged = true;
                        if (setOfNullable.contains(p.value)){
                            p = p.next;
                        }else break;
                    }
                }
            }
        }
        return table;
    }
    /**
     * follow集合的计算
     * @param ps 产生式列表
     * @return 每个非产生式的follow集合
     */
    private   Hashtable<String,HashSet<String>> follow(List<Production> ps){
        //初始化表
        Hashtable<String,HashSet<String>> table = new Hashtable<>();
        for(Production item:ps){
            table.put(item.left.value,new HashSet<>());
        }
        table.get(ps.get(0).left.value).add("$");
        boolean isChanged = true;

        while (isChanged){
            isChanged = false;
            for(Production item:ps){
                Stack<GrammarSymbol> ss = new Stack<>();
                GrammarSymbol tp = item.right;
                while (tp!=null){
                    ss.push(tp);
                    tp = tp.next;
                }
                HashSet<String> temp = new HashSet<>();
                GrammarSymbol prePart = null;
                while (!ss.isEmpty()){
                    GrammarSymbol currentPart = ss.pop();

                    if (currentPart.type == GrammarSymbol.T){
                        temp.add(currentPart.value);
                    }
                    else if(currentPart.type== GrammarSymbol.NT){
                        //如果是最后一个非终结符 例如 E->TM  中的M
                        if(currentPart.next ==null){
                            followU(followAs(table,currentPart),followAs(table,item.left));
                        }else{
                            HashSet<String> followOfCurrentPart = followAs(table,currentPart);
                            if (followU(followOfCurrentPart,firstAs(prePart))){
                                isChanged = true;
                            }
                            if (followU(followOfCurrentPart,temp)){
                                isChanged = true;
                                temp.clear();
                            }
                            if (isNullable(prePart)){
                                if (followU(followOfCurrentPart,followAs(table,prePart))) isChanged = true;
                            }
                        }
                    }
                    prePart = currentPart;
                }
            }
        }
        return  table;
    }
    private  HashSet<String> firstAs(GrammarSymbol p){
        if (p==null) return new HashSet<>();
        else if (first.containsKey(p.value)) return first.get(p.value);
        else return new HashSet<>();
    }
    private HashSet<String> followAs(Hashtable<String,HashSet<String> >tableOfFollow, GrammarSymbol p){
        if (p==null) return new HashSet<>();
        else if (tableOfFollow.containsKey(p.value)) return tableOfFollow.get(p.value);
        else return new HashSet<>();
    }
    private  boolean  followU(HashSet<String> a,HashSet<String> b){
        int prel = a.size();
        for(String v:b){
            if (!v.equals("ε")){
                a.add(v);
            }
        }
        return !(prel==a.size());
    }
    private boolean isNullable(GrammarSymbol part){
        if(part==null) return true;
        if (setOfNullable.contains(part.value)) return true;
        return false;
    }
    public HashMap<String,HashSet<String>> buildSelect (List<Production> items){

        HashMap<String,HashSet<String>> selects = new HashMap<>();
        String preV = "";
        int productIndex = 1;
        for (Production item:items) {
            if (!item.left.value.equals(preV)) {
                productIndex = 1;
            } else {

                productIndex++;
            }
            HashSet<String> select = new HashSet<>();
            for (GrammarSymbol symbol : item.select) {
                select.add(symbol.value);
            }
            selects.put(item.left.value + "_" + productIndex,select);
            preV = item.left.value;
        }

        return selects;
    }

    public static void outSelect(HashMap<String,HashSet<String>> selects) {

            FileOutputStream outputStream = null;
            BufferedOutputStream bufferedOutputStream = null;
            StringBuilder builder = new StringBuilder();
            for (String key: selects.keySet()){
                builder.append("SELECT("+ key +") { ");
                for (String v:selects.get( key )){
                    builder.append(v + " ");
                }
                builder.append("}\n");
            }
            try {
                outputStream = new FileOutputStream(new File("select.txt"));
                bufferedOutputStream = new BufferedOutputStream(outputStream);
                bufferedOutputStream.write(builder.toString().getBytes());
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    bufferedOutputStream.close();
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

    }
    public static void main(String[] args) {
        Integer i = new Integer(10);


    }


}
