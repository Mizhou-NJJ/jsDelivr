package com.grammar;

public class GrammarSymbol {
    public static final int T = 0;//终结符
    public static final int NT = 1;// 非终结符
    public static final int EPS = 2; // 空串
    public static final String EPSILON = "ε";
    public String value;
    public int type;
    public GrammarSymbol next;
    public GrammarSymbol(String value,int type,GrammarSymbol next){
        this.value = value;
        this.type = type;
        this.next = next;
    }
    public GrammarSymbol(String value,int type){
        this.value = value;
        this.type =type;
    }
    public GrammarSymbol(){

    }
}
