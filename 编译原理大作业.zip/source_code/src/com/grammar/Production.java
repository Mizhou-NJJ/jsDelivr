package com.grammar;

import java.util.HashSet;

public class Production {
    public  GrammarSymbol left;
    public GrammarSymbol right;
    // 用于存放每条产生的select集合，也就是产生式左部的非终极符
    public HashSet<GrammarSymbol> select = new HashSet<>();


}
