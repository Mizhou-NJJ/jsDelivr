package com.parser;

public class ParseExpression {
    public ParseExpression(){
    }

}
