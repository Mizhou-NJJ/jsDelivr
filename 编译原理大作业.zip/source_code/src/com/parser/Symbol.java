package com.parser;

public class Symbol {
    //变量名
    public String varName;
    //变量大小 如 int = 4
    public int size;
    //变量类型
    public String varType;
    //变量值
    public String value;
    public boolean isInit;
    public Symbol(){

    }
}
